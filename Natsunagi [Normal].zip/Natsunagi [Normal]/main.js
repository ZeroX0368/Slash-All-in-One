const { 
    Client, 
    GatewayIntentBits, 
    EmbedBuilder, 
    Events, 
    ModalBuilder, 
    TextInputBuilder, 
    TextInputStyle, 
    ActionRowBuilder, 
    ActivityType, 
    ButtonBuilder, 
    ButtonStyle, 
} = require('discord.js');
const axios = require('axios');
const { token, clientId, apiKey, Endpoint, OwnerName, rlowisgay, iconlink, monkey, iconfooter } = require('./config.json');
const BypassModal = require('./bypass');
const moment = require('moment-timezone'); // Import moment-timezone

const path = require('path');

const client = new Client({ 
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
    ] 
});

// Event handler when the bot is ready
client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
});

// Sự kiện khi client sẵn sàng
client.once('ready', async () => {
    console.log(`Logged in as ${client.user.tag}`);

    // Đặt trạng thái của bot thành DND
    client.user.setPresence({
        activities: [{ name: 'https://discord.gg/UQjPG97yYV', type: ActivityType.Playing }],
        status: 'dnd', // Trạng thái Do Not Disturb
    });

    try {
        const commands = [
            {
                name: 'bypass',
                description: 'Whitelist/Get Key'
            },
        ];

        await client.application.commands.set(commands);
        console.log('Commands registered globally');
    } catch (error) {
        console.error('Error registering commands:', error);
    }
});

client.on(Events.InteractionCreate, async (interaction) => {

        switch (interaction.commandName) {
            case 'bypass':
                const modal = new ModalBuilder()
                    .setCustomId('bypassmodal')
                    .setTitle('Bypass Link')
                    .addComponents(
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder()
                                .setCustomId('link')
                                .setLabel('Input Your Link:')
                                .setStyle(TextInputStyle.Short)
                        )
                    );

                await interaction.showModal(modal);
                break;
        }
    }
);

    if (interaction.isModalSubmit() && interaction.customId === 'bypassmodal') {
        const url = interaction.fields.getTextInputValue('link');

        if (url.startsWith('https://flux.li/android/external/start.php?HWID=')) {
            await fluxus(interaction);
        } else if (url.startsWith('https://gateway.platoboost.com/a/')) {
            await delta(interaction);
        } else if (url.startsWith('https://mobile.codex.lol')) {
            await codex(interaction);
        }
    }

async function fluxus(interaction) {
    const link = interaction.fields.getTextInputValue('link');
    const box = '```';
            const inviteButton = new ButtonBuilder()
                .setLabel('Invite Me')
                .setStyle(ButtonStyle.Link)
                .setURL('https://discord.com/oauth2/authorize?client_id=1265214436197666837'); // Thay bằng liên kết mời bot của bạn

            const supportButton = new ButtonBuilder()
                .setLabel('Support Server')
                .setStyle(ButtonStyle.Link)
                .setURL('https://discord.gg/UQjPG97yYV'); // Thay bằng liên kết máy chủ hỗ trợ của bạn

            const actionRow = new ActionRowBuilder()
                .addComponents(inviteButton, supportButton);

    if (!link.startsWith('https://flux.li/android/external/start.php?HWID=')) {
        await interaction.reply({ content: 'Invalid link format!', ephemeral: true });
        return;
    }

    const bypass_endpoints = [
        'https://flux.li/android/external/start.php?HWID='
    ];

    const api_url = bypass_endpoints.find(endpoint => link.startsWith(endpoint));

    if (!api_url) {
        await interaction.reply({ content: 'This link is under maintenance or not supported', ephemeral: true });
        return;
    }

    const final_api_url = 
          `YOUR API`;

console.log(final_api_url);

    try {
        await interaction.deferReply({ ephemeral: false });
        const response = await axios.get(final_api_url);

        if (response.status !== 200) {
            throw new Error('Something went wrong, try again later!');
        }

        const primary_response = response.data;

        if (!primary_response.key) {
            throw new Error('An error occurred. Please try again later!');
        }

        const bypass_result = primary_response.key;
        if (!bypass_result) {
            throw new Error('Key not found. Please try again with a valid link.');
        }

        const user = interaction.user;
        const avatar_url = user.displayAvatarURL();
        const embed = new EmbedBuilder()
            .setTitle('<a:uptimer:1264888502022307892> ғʟᴜxᴜs - sᴜᴄᴄᴇss')
            .setColor(0xf08080)
            .setAuthor({ name: rlowisgay, iconURL: iconlink, url: monkey })
            .setThumbnail(avatar_url)
            .setDescription(`${box}${bypass_result}${box}`)
            .setFooter({ text: `${OwnerName} | Request By ${user.username} | Today at ${moment().tz('Asia/Ho_Chi_Minh').format('HH:mm')}`, iconURL: iconfooter });

        await interaction.editReply({ embeds: [embed], components: [actionRow] });
        await interaction.followUp({ content: `${bypass_result}`, ephemeral: true });
    } catch (error) {
        const user = interaction.user;
        const avatar_url = user.displayAvatarURL();

        const embed = new EmbedBuilder()
            .setTitle('<a:offline:1264894843306377299> ғʟᴜxᴜs - ᴇʀʀᴏʀ')
            .setColor(0xFF2A04)
            .setAuthor({ name: rlowisgay, iconURL: iconlink, url: monkey })
            .setThumbnail(avatar_url)
            .setDescription(`${box}${error.message}${box}`)
            .setFooter({ text: `${OwnerName} | Request By ${user.username} | Today at ${moment().tz('Asia/Ho_Chi_Minh').format('HH:mm')}`, iconURL: iconfooter });

        await interaction.editReply({ embeds: [embed], components: [actionRow] });
        await interaction.followUp({ content: `# Join Now:\nhttps://discord.gg/b3xWhegCb9`, ephemeral: true });
    }
}

async function delta(interaction) {
    const link = interaction.fields.getTextInputValue('link');
    const box = '```';
            const inviteButton = new ButtonBuilder()
                .setLabel('Invite Me')
                .setStyle(ButtonStyle.Link)
                .setURL('https://discord.com/oauth2/authorize?client_id=1265214436197666837'); // Thay bằng liên kết mời bot của bạn

            const supportButton = new ButtonBuilder()
                .setLabel('Support Server')
                .setStyle(ButtonStyle.Link)
                .setURL('https://discord.gg/UQjPG97yYV'); // Thay bằng liên kết máy chủ hỗ trợ của bạn

            const actionRow = new ActionRowBuilder()
                .addComponents(inviteButton, supportButton);

    const bypass_endpoints = [
        'https://gateway.platoboost.com/a/'
    ];

    const api_url = bypass_endpoints.find(endpoint => link.startsWith(endpoint));

    if (!api_url) {
        await interaction.reply({ content: 'This link is under maintenance or not supported', ephemeral: true });
        return;
    }

    const final_api_url = `YOUR API`;

    console.log(final_api_url);

    try {
        await interaction.deferReply({ ephemeral: false });
        const response = await axios.get(final_api_url);

        if (response.status !== 200) {
            throw new Error('Something went wrong, try again later!');
        }

        const primary_response = response.data;

        const bypass_result = primary_response.key;
        if (!bypass_result) {
            throw new Error('Key not found. Please try again with a valid link.');
        }

        const user = interaction.user;
        const avatar_url = user.displayAvatarURL();
        const embed = new EmbedBuilder()
            .setTitle('<a:uptimer:1264888502022307892> ᴘʟᴀᴛᴏʙᴏᴏsᴛ - sᴜᴄᴄᴇss')
            .setColor(0xf08080)
            .setAuthor({ name: rlowisgay, iconURL: iconlink, url: monkey })
            .setThumbnail(avatar_url)
            .setDescription(`${box}${bypass_result}${box}`)
            .setFooter({ text: `${OwnerName} | Request By ${user.username} | Today at ${moment().tz('Asia/Ho_Chi_Minh').format('HH:mm')}`, iconURL: iconfooter });

        await interaction.editReply({ embeds: [embed], components: [actionRow] });
        await interaction.followUp({ content: `${bypass_result}`, ephemeral: true });
    } catch (error) {
        const user = interaction.user;
        const avatar_url = user.displayAvatarURL();

        const embed = new EmbedBuilder()
            .setTitle('<a:offline:1264894843306377299> ᴘʟᴀᴛᴏʙᴏᴏsᴛ - ᴇʀʀᴏʀ')
            .setColor(0xFF2A04)
            .setAuthor({ name: rlowisgay, iconURL: iconlink, url: monkey })
            .setThumbnail(avatar_url)
            .setDescription(`${box}${error.message}${box}`)
            .setFooter({ text: `${OwnerName} | Request By ${user.username} | Today at ${moment().tz('Asia/Ho_Chi_Minh').format('HH:mm')}`, iconURL: iconfooter });

        await interaction.editReply({ embeds: [embed], components: [actionRow] });
        await interaction.followUp({ content: `# Join Now:\nhttps://discord.gg/b3xWhegCb9`, ephemeral: true });
    }
}

async function codex(interaction) {
    const link = interaction.fields.getTextInputValue('link');
    const box = '```';
            const inviteButton = new ButtonBuilder()
                .setLabel('Invite Me')
                .setStyle(ButtonStyle.Link)
                .setURL('https://discord.com/oauth2/authorize?client_id=1265214436197666837'); // Thay bằng liên kết mời bot của bạn

            const supportButton = new ButtonBuilder()
                .setLabel('Support Server')
                .setStyle(ButtonStyle.Link)
                .setURL('https://discord.gg/UQjPG97yYV'); // Thay bằng liên kết máy chủ hỗ trợ của bạn

            const actionRow = new ActionRowBuilder()
                .addComponents(inviteButton, supportButton);

    if (!link.startsWith('https://mobile.codex.lol')) {
        await interaction.reply({ content: 'Invalid link format!', ephemeral: true });
        return;
    }

    const bypass_endpoints = [
        'https://mobile.codex.lol'
    ];

    const api_url = bypass_endpoints.find(endpoint => link.startsWith(endpoint));

    if (!api_url) {
        await interaction.reply({ content: 'This link is under maintenance or not supported', ephemeral: true });
        return;
    }

    const final_api_url = 
          `YOUR API`;

console.log(final_api_url);

    try {
        await interaction.deferReply({ ephemeral: false });
        const response = await axios.get(final_api_url);

        if (response.status !== 200) {
            throw new Error('Something went wrong, try again later!');
        }

        const primary_response = response.data;

        const bypass_result = primary_response.key;
        if (!bypass_result) {
            throw new Error('Key not found. Please try again with a valid link.');
        }

        const user = interaction.user;
        const avatar_url = user.displayAvatarURL();
        const embed = new EmbedBuilder()
            .setTitle('<a:uptimer:1264888502022307892> ᴄᴏᴅᴇx - sᴜᴄᴄᴇss')
            .setColor(0xf08080)
            .setAuthor({ name: rlowisgay, iconURL: iconlink, url: monkey })
            .setThumbnail(avatar_url)
            .setDescription(`${box}${bypass_result}${box}`)
            .setFooter({ text: `${OwnerName} | Request By ${user.username} | Today at ${moment().tz('Asia/Ho_Chi_Minh').format('HH:mm')}`, iconURL: iconfooter });

        await interaction.editReply({ embeds: [embed], components: [actionRow] });
        await interaction.followUp({ content: `## ᴊᴏɪɴ ᴍʏ sᴇʀᴠᴇʀ ɴᴏᴡ:\nhttps://discord.gg/UQjPG97yYV`, ephemeral: true });
    } catch (error) {
        const user = interaction.user;
        const avatar_url = user.displayAvatarURL();

        const embed = new EmbedBuilder()
            .setTitle('<a:offline:1264894843306377299> ᴄᴏᴅᴇx - ᴇʀʀᴏʀ')
            .setColor(0xFF2A04)
            .setAuthor({ name: rlowisgay, iconURL: iconlink, url: monkey })
            .setThumbnail(avatar_url)
            .setDescription(`${box}${error.message}${box}`)
            .setFooter({ text: `${OwnerName} | Request By ${user.username} | Today at ${moment().tz('Asia/Ho_Chi_Minh').format('HH:mm')}`, iconURL: iconfooter });

        await interaction.editReply({ embeds: [embed], components: [actionRow] });
        await interaction.followUp({ content: `# Join Now:\nhttps://discord.gg/b3xWhegCb9`, ephemeral: true });
    }
}

client.login(token);