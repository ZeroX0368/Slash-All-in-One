const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');

class BypassModal {
    constructor() {
        this.modal = new ModalBuilder()
            .setCustomId('bypassmodal')
            .setTitle('Bypass Link');
        this.link = new TextInputBuilder()
            .setCustomId('link')
            .setLabel('Input Your Link:')
            .setStyle(TextInputStyle.Short);
        const row = new ActionRowBuilder().addComponents(this.link);
        this.modal.addComponents(row);
    }
}

module.exports = BypassModal;